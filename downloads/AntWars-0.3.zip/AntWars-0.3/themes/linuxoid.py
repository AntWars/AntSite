self.theme = {
    'BG_COLOR': 'black',
    'EMPTY_CELL_COLOR': 'white',
    'OUTLINE_COLOR': 'black',
    'EMPTY_OUTLINE': True,
    'FOOD_COLOR': 'red',
    'BASE_COLOR': 'black',
    'CELL_SIZE': 10
}
