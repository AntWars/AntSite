self.theme = {
    'BG_COLOR': 'white',
    'EMPTY_CELL_COLOR': 'blanched almond',
    'OUTLINE_COLOR':'blanched almond',
    'EMPTY_OUTLINE': False,
    'FOOD_COLOR': 'lime green',
    'BASE_COLOR': 'black',
    'CELL_SIZE': 20
}
