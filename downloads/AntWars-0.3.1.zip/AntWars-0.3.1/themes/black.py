self.theme = {
    'BG_COLOR': 'black',
    'EMPTY_CELL_COLOR': 'black',
    'OUTLINE_COLOR': 'black',
    'EMPTY_OUTLINE': False,
    'FOOD_COLOR': 'red',
    'BASE_COLOR': 'white',
    'CELL_SIZE': 20
}
